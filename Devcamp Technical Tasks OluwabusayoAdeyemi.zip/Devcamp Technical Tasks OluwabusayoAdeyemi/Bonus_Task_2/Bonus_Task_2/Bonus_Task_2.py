#Oluwabusayo Adeyemi Bonus Task_2

#Defining the srting conmpose function
def string_compose(value):
#Covert to array
     array =list(value)
#Create the vowel bucket
     vowel = ['a','e','i','o','u']
     for i in range(len(array)): 
#Check for all condition int the question
        if array[i] in vowel:
            array[i] = array[i]
        elif (array[i] == 'z'): 
                array[i] = 'b' 
        elif (array[i] == 'd'): 
                array[i] = 'f'
        elif (array[i] == 'h'): 
                array[i] = 'j'
        elif (array[i] == 'n'): 
                array[i] = 'p'
        elif (array[i] == 't'): 
                array[i] = 'v'
        elif (array[i] == ' '): 
                array[i] = ' '
        else: 
             array[i] = chr(ord(array[i]) + 1)
#using the join method
     return ''.join(array) 
  
print(string_compose('hello world')) 

 
