#Oluwabusayo Adeyemi Task_5

#A function using the replace method

def replace_all(space):
    new_value = space.replace(" ","%20")
    print(new_value)

replace_all("Mr John Smith")