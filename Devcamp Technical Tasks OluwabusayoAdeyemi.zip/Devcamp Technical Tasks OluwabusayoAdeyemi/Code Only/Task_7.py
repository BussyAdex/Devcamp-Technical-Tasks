# Oluwabusayo Adeyemi Task_7

#calculates the standard deviation of the numbers
#declearing the function
def standard_deviation (array_number):
    sum = 0
    sum_squares = 0
    length_array = len(array_number)
#calculate the mean
    for number in array_number:
        sum += number
    mean = sum/length_array
#calculate the sum of squares
    for numb in array_number:
        sum_squares +=(numb - mean)**2
#calculate the standard derviation 
    stand_dev = (sum_squares/length_array)**0.5
    print ("Standard Deviation answer is :",stand_dev)

standard_deviation([23,24,35,6,10])

