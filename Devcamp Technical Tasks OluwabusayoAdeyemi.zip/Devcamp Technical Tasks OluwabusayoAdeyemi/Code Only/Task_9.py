#Oluwabusayo Adeyemi Task_9

#Declaring the function
def palindrome_string (in_string):
#reverse the string
    new_string = in_string[::-1]
#Checking if both are equal
    if (new_string == in_string):
        return ("Yes")
    else:
        return("No")
 
print(palindrome_string("madam"))