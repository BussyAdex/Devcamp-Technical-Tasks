#Oluwabusayo Adeyemi Task 2
#Declearing the function
def prime_number (prime):
   if prime > 1 :
       for num in range(2,prime):
           if (prime % num) == 0:
               return False
               break
       else:
            return True
#Example of the function             
print(prime_number(47))

