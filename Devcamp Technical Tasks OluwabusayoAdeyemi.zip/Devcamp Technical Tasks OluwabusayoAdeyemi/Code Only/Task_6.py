#Oluwabusayo Adeyemi Task_6
#Defining the three number function
def three_number(array_num, target):
    Array = array_num
    array_size =len(array_num)
    new_array = []
#To get the first element  
    for i in range(0, array_size-2): 
#To get the second element  
        for j in range(i + 1, array_size-1):  
#To get the third element 
            for k in range(j + 1, array_size): 
                if Array[i] + Array[j] + Array[k] == target: 
                   new_array.append(Array[i])
                   new_array.append(Array[j]) 
                   new_array.append(Array[k]) 
                   print(new_array)
                break
            return -1
            
three_number([1,2, 3, 4, 5, 6],6)