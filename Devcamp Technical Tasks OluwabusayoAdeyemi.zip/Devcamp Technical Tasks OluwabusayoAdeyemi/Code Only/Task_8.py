#Oluwabusayo Adeyemi Task_8

#declaring the function
def count_number (number):
    count = 1
    new_array = []
#adding 1 to number is to make the last value inclusive
    for num in range(0, number+1):
        if (num%10)==3 or (num //10 == 3):
            count += 1
            new_array.append(num)
    print("count:",count," numbers:",new_array)

count_number(35)
