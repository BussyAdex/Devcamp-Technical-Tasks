#Oluwabusayo Adeyemi Task_10
#define the function
def most_character (word):
    highest = 0 
#creating the VARCHAR count
    count = [0] *256  
    for chact in word : 
#increase the count position by 1
       count[ord(chact)] += 1
    for chact in word :
#getting the highest number of character
       if(count[ord(chact)] > highest):
        highest = count[ord(chact)] 
    print(chact)  

most_character("afhuusnimr443o0sggg")