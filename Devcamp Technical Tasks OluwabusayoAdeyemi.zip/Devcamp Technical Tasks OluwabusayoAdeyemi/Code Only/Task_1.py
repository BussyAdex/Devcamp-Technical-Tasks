#Oluwabusayo Adeyemi Task_1

#Declaring the function
def calculate_the_sum (pos_integer):
    even_integer = 0
    odd_integer = 0
    array_integer = []
    for pos in pos_integer:
        if pos >= 0 :
#This will check if it is a number
            if pos % 2 == 0 :
                even_integer += pos
            else:
                odd_integer += pos

        else:
            print("There is a negative integer")
#This will append answer to an array and print
    array_integer.append(even_integer)
    array_integer.append(odd_integer)
    print(array_integer)
   
calculate_the_sum([1,4,3,3,5,8,9,2])


