#Oluwabusayo Adeyemi Task 3

#Declearing the function
def prime_number (prime_num):
    array_prime = []
#getting each number in the array 
    for prime in prime_num:
        if prime > 1 :
            for num in range(2, prime):
#Check if it is a prime number
                if (prime % num) == 0:
                 break
            else:  
                 array_prime.append(prime)
    print(array_prime)
           
#Example of the function             
prime_number([47,2,34,5,7,8])
 

