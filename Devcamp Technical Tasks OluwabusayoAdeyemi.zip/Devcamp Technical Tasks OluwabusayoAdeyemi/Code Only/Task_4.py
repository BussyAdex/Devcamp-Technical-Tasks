#Oluwabusayo Adeyemi Task_4

#The print function helps with comments

def password_validator(password):
    SpecialSymbol=['!','@','#','$','%']
    check=True
    if not any(char.isdigit() for char in password):
            print('very weak e.g. a password with only strings')
            check=False
            return 0
    if any(char.isdigit() for char in password):
            print('weak e.g. a password with only numbers')
            check=False
            return 1
    if not any(char in SpecialSymbol for char in password):
            print('strong e.g. a password containing strings and numbers')
            check=False
            return 2
    if check:
        print('very strong e.g. a password containing strings, numbers and special characters (!,@,#,$,%, etc)')
        return 3
        

print(password_validator("234tes@"))